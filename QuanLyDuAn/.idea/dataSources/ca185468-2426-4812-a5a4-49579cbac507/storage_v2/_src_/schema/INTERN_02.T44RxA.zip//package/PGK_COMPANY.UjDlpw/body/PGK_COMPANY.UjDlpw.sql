create package body pgk_company as
    
    
    procedure delete_company(p_id String, p_user_update String)as
    begin

        update COMPANY c
        set c.STATUS = -1,c.DATE_UPDATE = current_date,c.USER_UPDATE = p_user_update
        where c.COMPANY_ID = p_id;

        -----------------company project --------------------

        update company_project cp
        set cp.STATUS = -1,cp.USER_UPDATE = p_user_update,cp.DATE_UPDATE = current_date
        where cp.company_project_id  in 
                                (
                                    select cp1.company_project_id from company_project cp1
                                    where cp1.COMPANY_ID = p_id
                                );
        


        -------------job_detail----------------------


        update JOB_DETAIL jd
        set jd.STATUS = -1,jd.USER_UPDATE = p_user_update,jd.DATE_UPDATE = current_date
        where jd.JOB_DETAIL_ID  in 
                                (
                                    select jd1.JOB_DETAIL_ID from JOB_DETAIL jd1
                                    where jd1.COMPANY_ID = p_id
                                );


        -------------timesheet_detail-----------

        update timesheet_detail td
        set td.STATUS = -1,td.USER_UPDATE = p_user_update,td.DATE_UPDATE = current_date
        where td.TIMESHEET_DETAIL_ID in 
                                (
                                    select td1.timesheet_detail_id from timesheet_detail td1
                                    where td1.COMPANY_ID = p_id
                                );



        -------------salary-----------------
        update salary s
        set s.STATUS = -1,s.USER_UPDATE = p_user_update,s.DATE_UPDATED = current_date
        where s.SALARY_ID  in 
                                (
                                    select s.SALARY_ID from salary s1
                                    where s1.COMPANY_ID = p_id
                                );



    end;    


end pgk_company;
/

