create PACKAGE BODY pgk_contract AS

    PROCEDURE delete_contract (
        p_contract_id     IN STRING,
        p_person_update   IN STRING
    )
        AS
    BEGIN
        UPDATE contract c
            SET
                c.status =-1,
                c.date_updated = current_date,
                c.user_updated = p_person_update
        WHERE
            c.contract_id = p_contract_id;

        UPDATE salary s
            SET
                s.status =-1,
                s.date_updated = current_date,
                s.user_update = p_person_update
        WHERE
            s.contract_id = p_contract_id;

    END delete_contract;

END pgk_contract;
/

