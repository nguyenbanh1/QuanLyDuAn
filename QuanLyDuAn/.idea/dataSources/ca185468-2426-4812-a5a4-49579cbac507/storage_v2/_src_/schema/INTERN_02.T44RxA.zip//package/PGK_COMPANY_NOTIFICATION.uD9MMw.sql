create package pgk_company_notification as

    procedure delete_company_notification(p_id String,p_user_update String);
    procedure get_company_noti(rest out sys_refcursor, p_company_noti_type String,p_applyfor String);
    
end pgk_company_notification;
/

