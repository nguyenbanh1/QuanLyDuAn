create package pgk_apply_for_detail as
    
    procedure delete_apply_for_detail(p_id String ,p_user_update String);

end pgk_apply_for_detail;
/

