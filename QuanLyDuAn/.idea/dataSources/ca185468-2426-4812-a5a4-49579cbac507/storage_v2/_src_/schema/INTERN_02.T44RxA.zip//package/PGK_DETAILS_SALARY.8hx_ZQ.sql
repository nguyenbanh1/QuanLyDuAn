create PACKAGE pgk_details_salary AS 

    PROCEDURE delete_details_salary (
        p_details_salary_id STRING 
    );

    FUNCTION get_all (
        p_details_salary_id STRING
    ) RETURN SYS_REFCURSOR;
    
   

END pgk_details_salary;
/

