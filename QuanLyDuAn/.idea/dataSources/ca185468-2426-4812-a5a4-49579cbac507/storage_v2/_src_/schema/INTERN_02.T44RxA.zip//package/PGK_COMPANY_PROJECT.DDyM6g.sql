create PACKAGE pgk_company_project AS
    PROCEDURE delete_company_project (
        p_company_id STRING,
        p_user_update STRING
    );

    PROCEDURE get_all_ds_project (
        o_res                           OUT SYS_REFCURSOR,
        p_company_project_id string,
        p_staff_id string,
        p_schedule_start_time date,
        p_schedule_end_time date
    );
    
    PROCEDURE get_one(
    o_res OUT SYS_REFCURSOR,
    o_res1 OUT SYS_REFCURSOR,
    p_company_project_id STRING    
    );

END pgk_company_project;
/

