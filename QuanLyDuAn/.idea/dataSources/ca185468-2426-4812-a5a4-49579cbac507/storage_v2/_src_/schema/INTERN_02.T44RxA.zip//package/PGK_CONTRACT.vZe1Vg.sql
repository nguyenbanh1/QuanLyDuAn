create PACKAGE pgk_contract AS
    PROCEDURE delete_contract (
        p_contract_id     IN STRING,
        p_person_update   IN STRING
    );

END pgk_contract;
/

