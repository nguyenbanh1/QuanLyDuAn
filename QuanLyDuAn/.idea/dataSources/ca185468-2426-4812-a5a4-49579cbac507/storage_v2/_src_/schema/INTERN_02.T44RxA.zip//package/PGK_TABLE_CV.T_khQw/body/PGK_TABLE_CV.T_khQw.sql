create PACKAGE BODY pgk_table_cv AS

    PROCEDURE get_all (
        o_res                    OUT SYS_REFCURSOR,
        p_cv_name                STRING,
        p_recruitment_position   STRING,
        p_date_recruitment       DATE
    ) AS
    BEGIN
        OPEN o_res FOR SELECT
                           cv_name,
                           date_recruitment,
                           recruitment_position,
                           presenter,
                           email,
                           mobile_phone,
                           result,
                           note_recruitment,
                           link_cv
                       FROM
                           table_cv
                       WHERE
                           ( ( p_cv_name IS NULL
                               OR huy_dau_va_in_hoa(table_cv.cv_name) LIKE '%'
                                                                              || huy_dau_va_in_hoa(p_cv_name)
                                                                              || '%' )
                             AND ( p_recruitment_position IS NULL
                                   OR huy_dau_va_in_hoa(table_cv.recruitment_position) LIKE '%'
                                                                                               || huy_dau_va_in_hoa(p_recruitment_position
                                                                                               )
                                                                                               || '%' )
                             AND ( p_date_recruitment IS NULL
                                   OR table_cv.date_recruitment = p_date_recruitment ) );

    END get_all;
    
    
    

    PROCEDURE delete_table_cv (
        p_cv_id STRING,
        p_person_update STRING
    ) AS
    BEGIN
        UPDATE table_cv
        SET
            table_cv.status =-1,
            user_update = p_person_update,
            date_update = current_date
        WHERE
            table_cv.cv_id = p_cv_id;

    END delete_table_cv;

END pgk_table_cv;
/

