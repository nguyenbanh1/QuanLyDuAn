create PACKAGE pgk_cycle AS
--Hữu Nhân 080818
    PROCEDURE delete_cycle (
        p_cycle_id        IN STRING,
        p_person_update   IN STRING
    );

END pgk_cycle;
/

