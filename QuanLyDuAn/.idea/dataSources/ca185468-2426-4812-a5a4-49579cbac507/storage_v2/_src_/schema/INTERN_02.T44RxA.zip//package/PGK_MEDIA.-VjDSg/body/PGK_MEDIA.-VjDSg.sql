create PACKAGE BODY pgk_media AS

    PROCEDURE delete_media (
        p_media_id STRING
    )
        AS
    BEGIN
        UPDATE media
            SET
                status =-1
        WHERE
            media_id = p_media_id;

        pgk_media_detail.delete_meida_detail_fk(p_media_id,'media');
    END delete_media;
    
    
    
    
    
    
    

    PROCEDURE delete_media1 (
        
        p_user_update   IN STRING,p_media_id      IN STRING
    )
        AS
    BEGIN
        UPDATE media
            SET
                media.date_update = current_date,
                media.user_update = p_user_update,
                media.status =-1
        WHERE
            media.media_id = p_media_id;

        UPDATE media_detail
            SET
                media_detail.date_update = current_date,
                media_detail.user_update = p_user_update,
                media_detail.status =-1
        WHERE
            media_detail.media_detail_id IN (
                SELECT
                    media_detail_id
                FROM
                    media_detail
                WHERE
                    media_id = p_media_id
            );

    END delete_media1;

END pgk_media;
/

