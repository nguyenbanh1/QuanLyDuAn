create PACKAGE pgk_map_project_staff AS
--Hữu Nhân 080818

    PROCEDURE delete_map_project_staff (
        p_id        IN STRING,
        p_person_update   IN STRING
    );
END pgk_map_project_staff;
/

