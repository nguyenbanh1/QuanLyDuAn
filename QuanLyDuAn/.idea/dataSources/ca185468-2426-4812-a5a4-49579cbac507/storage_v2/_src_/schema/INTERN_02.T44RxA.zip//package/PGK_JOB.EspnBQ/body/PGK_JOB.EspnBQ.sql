create PACKAGE BODY pgk_job AS

    PROCEDURE delete_job (
        p_job_id STRING,
        p_user_update STRING
    )
        AS
    BEGIN
        UPDATE JOB
            SET
                status =-1,
                user_update = p_user_update,
                date_update = current_date
            where JOB.JOB_ID = p_job_id;

        UPDATE job_detail jd
            SET
                jd.status =-1,
                jd.user_update = p_user_update,
                jd.date_update = current_date
        WHERE
            jd.job_detail_id IN (
                SELECT
                    job_detail.job_detail_id
                FROM
                    job_detail
                WHERE
                    jd.job_id = p_job_id
            );

    END delete_job;
    
    PROCEDURE GET_ALL_JOB(
    O_RES OUT SYS_REFCURSOR,
    p_JOB_ID STRING,
    P_JOB_CODE STRING,
    P_JOB_NAME STRING,
    P_JOB_DESCRIPTION STRING,
    P_JOB_EVALUATION STRING,
    P_SCHEDULE_START_TIME STRING,
    P_SCHEDULE_END_TIME STRING,
    P_ACTUAL_START STRING,
    P_ACTUAL_END STRING,
    P_MANAGER_ID STRING,
    P_CUSTOMER STRING,
    P_NUM_OF_MEMBERS STRING
)
    AS
    BEGIN
        OPEN O_RES FOR 
        SELECT 
        J.JOB_ID,J.JOB_CODE,J.JOB_DESCRIPTION,J.JOB_EVALUATION,J.SCHEDULE_START_TIME,
        J.SCHEDULE_END_TIME, J.ACTUAL_START, J.ACTUAL_END, S.STAFF_NAME,J.CUSTOMER,J.NUM_OF_MEMBERS
        FROM JOB J join MAP_USER M  ON M.MANAGER_ID = J.MANAGER_ID JOIN STAFF S ON M.STAFF_ID = S.STAFF_ID
        WHERE
        (p_JOB_ID  IS NULL OR J.JOB_ID = p_JOB_ID)AND
        (P_JOB_CODE IS NULL OR
        HUY_DAU_VA_IN_HOA(J.JOB_CODE) LIKE '%'||HUY_DAU_VA_IN_HOA(P_JOB_CODE)||'%'  ) 
        AND (P_JOB_NAME IS NULL OR 
        HUY_DAU_VA_IN_HOA(J.JOB_NAME) LIKE '%'||HUY_DAU_VA_IN_HOA(P_JOB_NAME)||'%' )
        AND (P_JOB_DESCRIPTION IS NULL OR
        HUY_DAU_VA_IN_HOA(J.JOB_DESCRIPTION ) LIKE '%'||HUY_DAU_VA_IN_HOA(P_JOB_DESCRIPTION)||'%' )
        AND (P_JOB_EVALUATION IS NULL OR 
        HUY_DAU_VA_IN_HOA(J.JOB_EVALUATION) LIKE '%'||HUY_DAU_VA_IN_HOA(P_JOB_EVALUATION)||'%' ) 
        AND (P_SCHEDULE_START_TIME IS NULL OR J.SCHEDULE_START_TIME = P_SCHEDULE_START_TIME)
        AND (P_SCHEDULE_END_TIME IS NULL OR J.SCHEDULE_END_TIME = P_SCHEDULE_END_TIME)
        AND (P_ACTUAL_START IS NULL OR J.ACTUAL_START = P_ACTUAL_START)
        AND (P_ACTUAL_END IS NULL OR J.ACTUAL_END = P_ACTUAL_END)
        AND (P_MANAGER_ID IS NULL OR 
        HUY_DAU_VA_IN_HOA(S.STAFF_NAME) LIKE '%'||HUY_DAU_VA_IN_HOA(P_MANAGER_ID)||'%' ) 
        AND (P_CUSTOMER IS NULL OR
        HUY_DAU_VA_IN_HOA(J.CUSTOMER) LIKE '%'||HUY_DAU_VA_IN_HOA(P_CUSTOMER)||'%' )
        AND (P_NUM_OF_MEMBERS IS NULL OR J.NUM_OF_MEMBERS = P_NUM_OF_MEMBERS);
    end GET_ALL_JOB ;
    
    
    

END pgk_job;
/

