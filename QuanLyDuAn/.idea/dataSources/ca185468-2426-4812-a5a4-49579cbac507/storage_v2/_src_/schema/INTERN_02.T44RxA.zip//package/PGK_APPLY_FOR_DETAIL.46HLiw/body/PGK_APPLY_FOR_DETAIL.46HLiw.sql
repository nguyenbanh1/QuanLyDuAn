create package body pgk_apply_for_detail as
    
    procedure delete_apply_for_detail(p_id String,p_user_update String)as
    begin

        update APPLY_FOR_DETAIL afd
        set afd.STATUS = -1,afd.DATE_UPDATED = current_date,afd.USER_UPDATED = p_user_update
        where afd.APPLY_FOR_ID = p_id;


        ----------------- configuration_detail-------------

        update CONFIGURATION_DETAIL cd
        set cd.STATUS = -1, cd.USER_UPDATE = p_user_update, cd.DATE_UPDATE =current_date
        where cd.CONFIGURATION_DETAIL_ID in 
                            (
                                select cd.CONFIGURATION_DETAIL_ID from CONFIGURATION_DETAIL cd
                                where cd.APPLY_FOR_DETAIL_ID = p_id
                            );



    end delete_apply_for_detail;

end pgk_apply_for_detail;
/

